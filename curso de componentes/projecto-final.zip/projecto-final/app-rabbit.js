import { CardRabbit } from './components/component.js';

